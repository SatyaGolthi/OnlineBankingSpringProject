package com.cg.obs.Service;

import java.time.LocalDate;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.cg.obs.Dao.BankDao;
import com.cg.obs.Dao.BankDaoImpl;
import com.cg.obs.Exception.OnlineException;
import com.cg.obs.entity.AccountMaster;
import com.cg.obs.entity.Customer;
import com.cg.obs.entity.Payee;
import com.cg.obs.entity.ServiceTracker;
import com.cg.obs.entity.Transaction;
import com.cg.obs.entity.User;



@Transactional(rollbackOn=OnlineException.class)
@Service
public class BankServiceImpl implements BankService {

	@Autowired
	BankDaoImpl dao;
	
	@Override
	public int addCustomer(Customer cust) throws OnlineException {
		
		return dao.addCustomer(cust);
	}

	@Override
	public List<Transaction> getTransactionDetails(LocalDate date)
			throws OnlineException {
		
		return dao.getTransactionDetails(date);
	}

	@Override
	public List<Customer> getCustomer(String name) throws OnlineException {
		
		return dao.getCustomer(name);
	}
	
	@Override
	public List<User> getUser(User user) throws OnlineException {
		
		return dao.getUser(user);
	}

	@Override
	public List<User> getUser(int id) throws OnlineException {

		return dao.getUser(id);
	}

	@Override
	public int updateCustomerStatus(User use) throws OnlineException {
		
		return dao.updateCustomerStatus(use);
	}

	

	@Override
	public void updateCustomer(Customer customer) throws OnlineException {
		
		dao.updateCustomer( customer );
	
	}

	@Override
	public Customer getCustomer(int accountId) throws OnlineException {
		
		return dao.getCustomer(accountId);
	}

	@Override
	public int addAccount(AccountMaster acc) throws OnlineException {
		
		return dao.addAccount(acc);
	}

	@Override
	public int operateServiceRequest(ServiceTracker service) throws OnlineException {
		
		return dao.operateServiceRequest(service);
	}

	@Override
	public ServiceTracker getServiceTracker(int id) throws OnlineException {
		
		return dao.getServiceTracker(id);
	}

	@Override
	public List<ServiceTracker> getAllServiceTracker(int id, LocalDate rdate) throws OnlineException {
		
		return dao.getAllServiceTracker(id, rdate);
	}

	@Override
	public List<Payee> getPayeeDetails(int accid) throws OnlineException {
		
		return dao.getPayeeDetails(accid);
	}

	@Override
	public AccountMaster getAccountDetails(int accId) throws OnlineException {

		return dao.getAccountDetails(accId);
	}

	@Override
	public int addPayeeDetails(Payee payee) throws OnlineException {
		
		return dao.addPayeeDetails(payee);
	}

	@Override
	public int updateBalance(double bal, int accId) throws OnlineException {
		
		return dao.updateBalance(bal, accId);
	}

	@Override
	public int addTransaction(Transaction trans) throws OnlineException {
		// TODO Auto-generated method stub
		return dao.addTransaction(trans);
	}

	@Override
	public void updateUser(User user) throws OnlineException {
		dao.updateUser(user);
	}

	@Override
	public User getUserr(int accId) throws OnlineException {
		
		return dao.getUserr(accId);
	}

	@Override
	public List<Transaction> getDetailedStatement(long accId, LocalDate fromDate, LocalDate toDate)
			throws OnlineException {
		
		return dao.getDetailedStatement(accId, fromDate, toDate);
	}

	@Override
	public List<Transaction> getMiniStatement(long accId) throws OnlineException {

		return dao.getMiniStatement(accId);
	}

}
