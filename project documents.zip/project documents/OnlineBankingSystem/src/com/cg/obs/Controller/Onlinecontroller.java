package com.cg.obs.Controller;
import java.sql.Date;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import com.cg.obs.Exception.OnlineException;
import com.cg.obs.Service.BankService;
import com.cg.obs.entity.AccountMaster;
import com.cg.obs.entity.Customer;
import com.cg.obs.entity.Payee;
import com.cg.obs.entity.ServiceTracker;
import com.cg.obs.entity.Transaction;
import com.cg.obs.entity.User;
@Controller
public class Onlinecontroller {
	@Autowired
	BankService service;
@RequestMapping(value="/obs")
public String getHomepage(Model m)
{
	return "Home";
}
@RequestMapping(value="/accountholders")
public String getLoginPage(Model m)
{
	return "login";
}
@RequestMapping(value="/options")
public String optionsMenu(Model m) {
	return "options";
}
@RequestMapping(value="/Home")
public String Home(Model m) {
	return "Home";
}
@RequestMapping(value="/adminHome")
public String AdminHome(Model m) {
	return "adminHome";
}
@RequestMapping(value="/logout")
public String Logout(Model m) {
	return "login";
}
@RequestMapping("mstatement")
public String showMiniStatement(HttpSession session,HttpServletRequest request)
{
	HttpSession sess=request.getSession(false);
	User user=(User) sess.getAttribute("user");
	try {
		List<Customer> tlist=service.getCustomer(user.getName());
		request.setAttribute("tlist", tlist);
		return "mstate";
	} catch (OnlineException e) {
		String error=e.getMessage();
		request.setAttribute("error",error);
		return "error";
	}
}
@RequestMapping("/mini.mvc")
public String showMini(@RequestParam("account_id") int accId,HttpServletRequest request)
{
	try {
		List<Transaction> tlist = service.getMiniStatement(accId);
		request.setAttribute("tlist",tlist);
		return "statement";
	}catch (OnlineException e) {
		String error=e.getMessage();
		request.setAttribute("error", error);
		return "error";
	}
}

@RequestMapping("detailstatement")
public String showDetailStatement(HttpSession session,HttpServletRequest request)
{
	HttpSession sess=request.getSession(false);
	User user=(User) sess.getAttribute("user");
	
	try {
		List<Customer> tlist=service.getCustomer(user.getName());
			request.setAttribute("tlist", tlist);
		return "detailstatement";
		
	} catch (OnlineException e) {
		String error=e.getMessage();
		request.setAttribute("error",error);
		return "error";
	}
}
@RequestMapping("details")
public String showDetailsPage(@RequestParam("account_id") int accId,@RequestParam("fromDate") String fromDate,@RequestParam("toDate") String toDate,HttpServletRequest request)
{
	DateTimeFormatter formatter1=DateTimeFormatter.ofPattern("yyyy-MM-dd");
	LocalDate fDate=LocalDate.parse(fromDate,formatter1);
	
	DateTimeFormatter formatter2=DateTimeFormatter.ofPattern("yyyy-MM-dd");
	LocalDate tDate=LocalDate.parse(toDate,formatter2);
	try {
		List<Transaction> tlist = service.getDetailedStatement(accId, fDate, tDate);
		request.setAttribute("tlist",tlist);
		return "showstatement";
	}catch (OnlineException e) {
		String error=e.getMessage();
		request.setAttribute("error", error);
		return "error";
	}
}
static int count=0;
@RequestMapping("check")
public String validUser(@RequestParam("user") int id,@RequestParam("pass") String pass,HttpServletRequest request)
{
	User user=new User();
	user.setUserId(id);
	user.setLoginPass(pass);
	if(count==3)
	{
		System.out.println(count);
	try {
		List<User> use=service.getUser(id);
		for(User u:use)
		{
			u.setStatus('L');
			service.updateCustomerStatus(u);
		}
			throw new OnlineException("Account is Blocked");
		} catch (OnlineException e1) {
			count++;
			String error1=e1.getMessage();
			request.setAttribute("error1",error1);
			request.setAttribute("count", count);
			return "login";
		}
	}if(count<3){
	try {
		
		List<User> use=service.getUser(user);
		if(!use.isEmpty())
		{
		User use1=use.get(0);
		if(use1.getStatus()=='U'){
			HttpSession sess=request.getSession(true);
			sess.setAttribute("user", use1);
			return "accountholderpage";
			}
			else{
				count=2;
				throw new OnlineException("Account is Blocked");
			}
		}
		else{
			throw new OnlineException("Wrong UserName and Password");
		}
	} catch (OnlineException e) {
		count++;
		String error=e.getMessage();
		request.setAttribute("error",error);
		//System.out.println(count);
		request.setAttribute("count", count);
		return "login";
	}
	}else{
		count=0;
		return "login";
	}
}
@RequestMapping(value="/UpdateCustomer.mvc", method=RequestMethod.GET)
public String getUpdateProductPage()
{
	return "UpdateCustomer";
}
@RequestMapping(value="/FetchCustomerByIDForUpdate.mvc", method=RequestMethod.GET)
public String processFetchCustomerDetailsFormForUpdate(
		@RequestParam("accountId") int accountId, 
		Model model)
{
	if( accountId <= 0 )
	{
		model.addAttribute("errMsg", "Id should be a valid positive Number");
		return "error";
	}
	
	try 
	{
		Customer customer = service.getCustomer(accountId);
		model.addAttribute("Customer", customer);
		return "UpdateCustomer";
	} 
	catch (Exception e) 
	{
		model.addAttribute("errMsg", "Could not fetch Customer Details: Reason: " + e.getMessage() );
		return "error";
	}
}
@RequestMapping(value="/ProcessUpdateCustomerForm.mvc", method=RequestMethod.POST)
public String processUpdateCustomerPageForm(
		@ModelAttribute("Customer") @Valid Customer customer,
		BindingResult validationResult,
		Model model
		)
{
	if( validationResult.hasErrors() )
	{
		
		return "UpdateCustomer";
	}
	try 
	{
		service.updateCustomer( customer );
		model.addAttribute( "info", "Customer updated successfully" );
		return "accountholderpage";
	}
	catch (OnlineException e) 
	{
		model.addAttribute("errMsg", "Something went wrong while trying "
				+ "to update the Customer. Reason " + e.getMessage());
		return "error";
	}	
}
@RequestMapping("reqCheque")

public String requestCheque(HttpServletRequest request,@RequestParam("serviceDescription") String serviceDescription)
{
	ServiceTracker sertrack=new ServiceTracker();
	sertrack.setServiceDescription(serviceDescription);	
	sertrack.setServiceRaisedDate(Date.valueOf(LocalDate.now()));
	sertrack.setServiceStatus("OPEN");
	 try {				
		int sid= service.operateServiceRequest(sertrack);
		request.setAttribute("requestCheque",sid);				
		return "RStatus";
	} catch (Exception e) {
		String error = e.getMessage();
		request.setAttribute("error", error);
		return "error";
	} 
}
@RequestMapping("servicerequest")
public String showServiceTracker(HttpServletRequest request)
{
		return "ServiceTracker";
}
@RequestMapping("tracker")
public String getServiceTracker(HttpServletRequest request,@RequestParam("serviceId") int sid)
{
	try {
		
		ServiceTracker stracker = service.getServiceTracker(sid);
		HttpSession sess= request.getSession(true);
		sess.setAttribute("servicetracker",stracker);
		return "Status";
	} catch (Exception e) {
		String error = e.getMessage();
		request.setAttribute("error", error);
		return "error";
	} 
}
@RequestMapping(value="/requestcheckbook")
public String Checkbook(Model m)
{
	return "checkbook";
}
@RequestMapping("fundtransfer")
public String showFundTransferPage(HttpServletRequest request)
{
return "fundtransferpage";
}

@RequestMapping("showpayee")
public String showPayee(HttpServletRequest request,@RequestParam("accID") int accId)
{
	try {
		List<Payee> plist=service.getPayeeDetails(accId);
		request.setAttribute("plist", plist);
		HttpSession sess1=request.getSession(true);
		sess1.setAttribute("acccId", accId);
		return "ShowPayee";
	} catch (OnlineException e) {
		String error=e.getMessage();
		request.setAttribute("error",error);
		return "error";
	}
}
@RequestMapping("verify")
public String verify(HttpServletRequest request,@RequestParam("accId") int accId,@RequestParam("nick") String nick)
{
	Payee payee=new Payee();
	payee.setAccountId(accId);
	payee.setNickName(nick);
	try{
		AccountMaster account=service.getAccountDetails(accId);
		if(account!=null)
		{
			HttpSession sess1=request.getSession(true);
			sess1.setAttribute("payeeDetails", payee);
			return "verify";
		}
		else{
			throw new OnlineException("Wrong Payee Account Id");
		}
	}catch(OnlineException e)
	{
		String error=e.getMessage();
		request.setAttribute("error",error);
		return "AddPayee";
	}
}
@RequestMapping("addpayee")
public String addPayee(HttpServletRequest request,@RequestParam("pin") String pin,HttpServletResponse response)
{
	if(pin.equals("abc345"))
	{
		Payee payee=new Payee();
		HttpSession sess1=request.getSession(false);
		payee=(Payee) sess1.getAttribute("payeeDetails");
		int accId=(int) sess1.getAttribute("acccId");
		try {
			service.addPayeeDetails(payee);
			request.setAttribute("payee", payee);
			return showPayee(request, accId);
		}catch(OnlineException e)
		{
			String error=e.getMessage();
			request.setAttribute("error",error);
			return "AddPayee";
		}
	}
	else{
		String error="Pin not matched";
		request.setAttribute("error", error);
		return "verify";
	}
}
@RequestMapping("pay")
public String showPayPage(HttpServletRequest request,@RequestParam("amount") double amount,@RequestParam("pass") String password,@RequestParam("payeeAccId") int paccId) throws OnlineException
{
	HttpSession sess=request.getSession(false);
	User user=(User) sess.getAttribute("user");
	try {
		AccountMaster acc1=service.getAccountDetails(user.getAccId());
		AccountMaster acc2=service.getAccountDetails(paccId);
		if(acc1.getAccountBalance()>=amount)
		{
			if(password.equals(user.getTranPass()))
			{
				int rs=service.updateBalance(acc1.getAccountBalance()-amount, user.getAccId());
				int rs1=service.updateBalance(acc2.getAccountBalance()+amount, paccId);
				Transaction trans1=new Transaction();
				Transaction trans2=new Transaction();
				trans1.setAccountId(user.getAccId());
				trans1.setDateOfTransaction(Date.valueOf(LocalDate.now()));
				trans1.setTransactionAmount(amount);
				trans1.setTransactionDiscription("Fund Transfer");
				trans1.setTransactionType("W");
				int trs=service.addTransaction(trans1);
				trans2.setAccountId(paccId);
				trans2.setDateOfTransaction(Date.valueOf(LocalDate.now()));
				trans2.setTransactionAmount(amount);
				trans2.setTransactionDiscription("Fund Transfer");
				trans2.setTransactionType("D");
				int trs1=service.addTransaction(trans2);
				request.setAttribute("msg", "Transaction successfull from accId:");
				request.setAttribute("accId", trans1.getAccountId());
				return "success";
			}
			else{
				throw new OnlineException("Invalid Transaction password");
		}
		}
		else{
			throw new OnlineException("Insufficient Amount");
		}
		
	} catch (OnlineException e) {
		String error=e.getMessage();
		request.setAttribute("error",error);
		return "transaction";
	}
	}
@RequestMapping("payto")
public String payToPage(HttpServletRequest request,@RequestParam("from") int faccId,@RequestParam("to") int taccId,@RequestParam("amount") double tamount)
{
	try {
		AccountMaster acc1=service.getAccountDetails(faccId);
		AccountMaster acc2=service.getAccountDetails(taccId);
		System.out.println(acc1);
		System.out.println(acc2);
		if(acc1.getAccountBalance()>=tamount)
		{
			int rs=service.updateBalance(acc1.getAccountBalance()-tamount, faccId);
			int rs1=service.updateBalance(acc2.getAccountBalance()+tamount, taccId);
			System.out.println(" account balance updated ");
			Transaction trans1=new Transaction();
			Transaction trans2=new Transaction();
			trans1.setAccountId(faccId);
			trans1.setDateOfTransaction(Date.valueOf(LocalDate.now()));
			trans1.setTransactionAmount(tamount);
			trans1.setTransactionDiscription("Fund Transfer");
			trans1.setTransactionType("W");
			int trs=service.addTransaction(trans1);
			trans2.setAccountId(taccId);
			trans2.setDateOfTransaction(Date.valueOf(LocalDate.now()));
			trans2.setTransactionAmount(tamount);
			trans2.setTransactionDiscription("Fund Transfer");
			trans2.setTransactionType("D");
			int trs1=service.addTransaction(trans2);
			request.setAttribute("msg", "Transaction successfull from accId:"+faccId);
			request.setAttribute("accId", trans1.getAccountId());
			return "fsuccess";
		}
		else{
			throw new OnlineException("Invalid Amount");
		}	
	} catch (OnlineException e) {
		e.printStackTrace();
		String error=e.getMessage();
		request.setAttribute("error",error);
		return "transaction";
	}	
}

@RequestMapping(value="/changepassword.mvc")
public String Changepassword(Model m)
{
	return "changepasswordpage";
}
@RequestMapping(value="/FetchUserByIDForUpdate.mvc", method=RequestMethod.GET)
public String processFetchUserDetailsFormForUpdate(
		@RequestParam("accId") int accId, 
		Model model)
{
	if( accId <= 0 )
	{
		model.addAttribute("errMsg", "Id should be a valid positive Number");
		return "error";
	}
	try 
	{
		User user =  service.getUserr(accId);
		model.addAttribute("User", user);
		return "changepasswordpage";
	} 
	catch (Exception e) 
	{
		model.addAttribute("errMsg", "Could not fetch User Details: Reason: " + e.getMessage() );
		return "error";
	}
}
@RequestMapping(value="/ProcessUpdateUserForm.mvc", method=RequestMethod.POST)
public String processUpdateUserPageForm(
		@ModelAttribute("User") @Valid User user,
		BindingResult validationResult,
		Model model
		)
{
	if( validationResult.hasErrors() )
	{
		return "changepasswordpage";
	}
	try 
	{
		service.updateUser( user );
		model.addAttribute( "info", "User updated successfully" );
		return "accountholderpage";
	}
	catch (OnlineException e) 
	{
		model.addAttribute("errMsg", "Something went wrong while trying "
				+ "to update the User. Reason " + e.getMessage());
		return "error";
	}	
}
@RequestMapping(value="/admin.mvc")
public String getAdminLoginPage(Model m)
{
	return "admin";
}
@RequestMapping(value="/processadminLogin.mvc")
public String adminlogin(@RequestParam("username") String username,@RequestParam("password") String password, Model m)
{
	if(checkadminLogin(username, password))
		return "adminHome";
	else
	{
		m.addAttribute("errMsg","Login Failed! Try again.");
		return "admin";
	}
}
public boolean checkadminLogin(String username,String password)
{
	if(username.equals("admin")&&password.equals("1234"))
		return true;
	else
		return false;	
}
@RequestMapping(value="/addCustomer.mvc")
public String showAddCustomer(ModelMap map)
{
	AccountMaster account=new AccountMaster();
	Customer customer=new Customer();
	map.addAttribute("account", account);
	map.addAttribute("customer", customer);
	return "Account";
}
@RequestMapping(value="/add.mvc")
public String addCustomer(@ModelAttribute("account") AccountMaster account,BindingResult resultAccount,@ModelAttribute("customer") Customer customer,BindingResult resultCustomer,HttpServletRequest request)
{
	account.setOpenDate(Date.valueOf(LocalDate.now()));
	try {
		int accId=service.addAccount(account);
		customer.setAccountId(accId);
		service.addCustomer(customer);
		request.setAttribute("msg", "Customer Added Successfully:"+accId);
		request.setAttribute("cust", customer);
		return "success";
	} catch (OnlineException e) {
		String error=e.getMessage();
		request.setAttribute("error",error);
		return "error";
	}

}@RequestMapping(value="/view.mvc")
public String showTranscation(@RequestParam("time") int time,HttpServletRequest request)
{
	try{
	LocalDate date = null;
	switch(time)
	{
	case 1:
		date=LocalDate.now();
		break;
	case 2:
		date=LocalDate.now().minusMonths(1);
		break;
	case 3:
		date=LocalDate.now().minusMonths(3);
		break;
	case 4:
		date=LocalDate.now().minusYears(1);
	}
	List<Transaction> tList=service.getTransactionDetails(date);
	request.setAttribute("tList", tList);
	return "viewAllTransactionPage";
} catch(OnlineException e) {
	String error=e.getMessage();
	request.setAttribute("error",error);
	return "error";
}
}
}