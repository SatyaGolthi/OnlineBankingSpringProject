package com.cg.obs.Dao;

import java.math.BigDecimal;
import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;


import com.cg.obs.Exception.OnlineException;
import com.cg.obs.entity.AccountMaster;
import com.cg.obs.entity.Customer;
import com.cg.obs.entity.Payee;
import com.cg.obs.entity.ServiceTracker;
import com.cg.obs.entity.Transaction;
import com.cg.obs.entity.User;

@Repository
public class BankDaoImpl implements BankDao {
	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public int addCustomer(Customer cust) throws OnlineException {
		try{
			entityManager.persist(cust);
			entityManager.flush();
			}catch(Exception e)
			{
				throw new OnlineException("Unable to add the data");
			}
		return 1;
	}
	@Override
	public List<Transaction> getTransactionDetails(LocalDate date)
			throws OnlineException {
		try{
		String sql="SELECT trans FROM Transaction trans WHERE DATE_OF_TRANSACTION<= sysdate and DATE_OF_TRANSACTION>= :tdate";
		List<Transaction> tlist=new ArrayList<>();
		TypedQuery<Transaction> query=entityManager.createQuery(sql, Transaction.class);
		//query.setParameter("sysdate", Date.valueOf(LocalDate.now()));
		query.setParameter("tdate",  Date.valueOf(date));
		tlist=query.getResultList();
			return tlist;
		}catch(Exception e)
		{
			throw new OnlineException("Unable to fetch the data");
		}
}
	@Override
	public List<Customer> getCustomer(String name) throws OnlineException {
		try{
			String sql="SELECT cust from Customer cust WHERE Customer_Name=:name";
			List<Customer> clist=new ArrayList<>();
			TypedQuery<Customer> query=entityManager.createQuery(sql, Customer.class);
			query.setParameter("name", name);
			clist=query.getResultList();
			return clist;
			}catch(Exception e)
			{
				throw new OnlineException("Unable to fetch the data");
			}
	}
	

@Override
	public int updateCustomerStatus(User use) throws OnlineException {
		entityManager.merge(use);
		return 1;
	}
	@Override
	public List<User> getUser(int id) throws OnlineException {
		try{
			String sql="SELECT user FROM User user WHERE user_id= :id";
			TypedQuery<User> query=entityManager.createQuery(sql, User.class);
			query.setParameter("id", id);
			List<User> use=query.getResultList();
			return use;
		}catch(Exception e)
		{
			throw new OnlineException("Invalid User");
		}
	}
	
@Override
	public List<User> getUser(User user) throws OnlineException {
		try{
			String sql="SELECT user FROM User user WHERE user_id= :id  and login_password= :pass";
			TypedQuery<User> query=entityManager.createQuery(sql, User.class);
			query.setParameter("id", user.getUserId());
			query.setParameter("pass", user.getLoginPass());
			List<User> use=query.getResultList();
			return use;
		}catch(Exception e)
		{
			throw new OnlineException("Invalid User");
		}
	}

@Override
public void updateCustomer(Customer customer) throws OnlineException {
	try {
		entityManager.merge(customer);
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		throw new OnlineException(e.getMessage());
	}
	
}
@Override
public Customer getCustomer(int accountId) throws OnlineException {
Customer  customer = null;
	
	try 
	{

		System.out.println("dao");
		customer=entityManager.find(Customer.class, (int)accountId);//find(Transaction.class,accountId );
		
		
		if(customer==null)
			throw new OnlineException("No customers:"+accountId);
		
	}
		catch (OnlineException e) 
		{
			throw new OnlineException( e.getMessage() );
		}
		
	
	System.out.println(customer);
	return customer;
}
@Override
public int addAccount(AccountMaster acc) throws OnlineException {
	try{
		entityManager.persist(acc);
		entityManager.flush();
		
		Query query=entityManager.createNativeQuery("select account_id_seq.currval from dual");
		BigDecimal result=(BigDecimal) query.getSingleResult();
		return result.intValue();
		}catch(Exception e)
		{
			throw new OnlineException("Unable to add the data");
		}

}
@Override
public int operateServiceRequest(ServiceTracker service)
		throws OnlineException {
	try{
		entityManager.persist(service);
		entityManager.flush();
	Query query=entityManager.createNativeQuery("select service_id_seq.currval from dual");
	BigDecimal result=(BigDecimal) query.getSingleResult();
	return result.intValue();
	}catch(Exception e)
	{
		throw new OnlineException("Unable to add the data");
	}
}
@Override
public ServiceTracker getServiceTracker(int id) throws OnlineException {
	String sql= "select sertrack from ServiceTracker sertrack where service_id=:sid";
	try{
	TypedQuery<ServiceTracker> query=entityManager.createQuery(sql, ServiceTracker.class);
	query.setParameter("sid", id);
	ServiceTracker tracker=query.getSingleResult();
	return tracker;
	}catch(Exception e)
	{
		throw new OnlineException("Service id does not exist");
	}
}
@Override
public List<ServiceTracker> getAllServiceTracker(int id, LocalDate rdate)
		throws OnlineException {
	String sql="select sertracker from ServiceTracker sertracker where account_id= :id and service_raised_date>= :rdate";
	try{
	TypedQuery<ServiceTracker> query=entityManager.createQuery(sql, ServiceTracker.class);
	query.setParameter("id", id);
	query.setParameter("rdate", Date.valueOf(rdate));
	List<ServiceTracker> slist=new ArrayList<>();
	slist=query.getResultList();
	return slist;
	}catch(Exception e)
	{
		throw new OnlineException("Unable to fetch the data");
	}
}

@Override
	public List<Payee> getPayeeDetails(long accid) throws OnlineException {
		String sql="SELECT payee from Payee payee where account_id <> :accid";
		try{
			
		List<Payee> plist=new ArrayList<>();
		TypedQuery<Payee> query=entityManager.createQuery(sql, Payee.class);
		query.setParameter("accid", accid);
		plist=query.getResultList();
		return plist;
		}catch(Exception e)
		{
			throw new OnlineException("Unable to fetch the data");
		}
	}
	@Override
	public AccountMaster getAccountDetails(long accId) throws OnlineException {
		String sql="SELECT acc from AccountMaster acc WHERE Account_ID=:accId";
		AccountMaster acc=new AccountMaster();
		try{
			TypedQuery<AccountMaster> query=entityManager.createQuery(sql, AccountMaster.class);
			query.setParameter("accId",accId);
			acc=query.getSingleResult();
			return acc;
		}catch(Exception e)
		{
			throw new OnlineException("Unable to fetch the data");
		}
	}
	@Override
	public int addPayeeDetails(Payee payee) throws OnlineException {
		try{
		entityManager.persist(payee);
		entityManager.flush();
		return 1;
		}
		catch(Exception e)
		{
			throw new OnlineException("Unable to add the data");
		}
	}
	@Override
	public int updateBalance(double bal, int accId) throws OnlineException {
		
		
		AccountMaster acc=entityManager.find(AccountMaster.class, accId);
		acc.setAccountBalance((int)bal);
		
		
		
		entityManager.merge(acc);
		
		
		return 1;
	}
	@Override
	public int addTransaction(Transaction trans) throws OnlineException {
		entityManager.persist(trans);
		entityManager.flush();
		return 1;
	}
	@Override
	public void updateUser(User user) throws OnlineException {
		try {
			entityManager.merge(user);
		} catch (Exception e) {
			e.printStackTrace();
			throw new OnlineException(e.getMessage());
		}
		
	}
	@Override
	public User getUserr(int accId) throws OnlineException {
		User  user = null;
		
		try 
		{

			System.out.println("dao");
			user=entityManager.find(User.class, (int)accId);//find(Transaction.class,accountId );
			
			
			if(user==null)
				throw new OnlineException("No customers:"+accId);
			
		}
			catch (OnlineException e) 
			{
				throw new OnlineException( e.getMessage() );
			}
			
		
		System.out.println(user);
		return user;
	}
	@Override
	public List<Transaction> getDetailedStatement(long accId, LocalDate fromDate, LocalDate toDate)
			throws OnlineException {
		try{
			String  sql =" SELECT trans FROM Transaction trans where (account_id=:accId) AND (date_of_transaction  BETWEEN :fromDate AND :toDate ) ORDER BY date_of_transaction DESC";
			List<Transaction> tlist= new ArrayList<>();
			TypedQuery<Transaction> query=entityManager.createQuery(sql, Transaction.class);
			query.setParameter("accId", accId);
			query.setParameter("fromDate", Date.valueOf(fromDate));
			query.setParameter("toDate", Date.valueOf(toDate));
			tlist=query.getResultList();
			return tlist;
			}catch(Exception e)
			{
				throw new OnlineException("Unable to fetch the data");
			}
	
}
	@Override
	public List<Transaction> getMiniStatement(long accId) throws OnlineException {
		try{
			
			String sql="select trans from Transaction trans where account_id= :accId ORDER BY date_of_transaction DESC";
			List<Transaction> tlist= new ArrayList<>();
			TypedQuery<Transaction> query=entityManager.createQuery(sql, Transaction.class);
			query.setParameter("accId", accId);
			tlist=query.getResultList();
			int n=tlist.size();
			for(int i=n-1;i>=10;i--)
			{
				tlist.remove(i);
			}
			return tlist;
			}catch(Exception e)
			{
				throw new OnlineException("Unable to fetch the data");
			}
	}

}

