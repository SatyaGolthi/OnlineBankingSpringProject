package com.cg.obs.Dao;

import java.time.LocalDate;
import java.util.List;


import com.cg.obs.Exception.OnlineException;
import com.cg.obs.entity.AccountMaster;
import com.cg.obs.entity.Customer;
import com.cg.obs.entity.Payee;
import com.cg.obs.entity.ServiceTracker;
import com.cg.obs.entity.Transaction;
import com.cg.obs.entity.User;




public interface BankDao {

	public int addCustomer(Customer cust) throws OnlineException;
	public Customer getCustomer( int accountId ) throws OnlineException;
	public User getUserr( int accId ) throws OnlineException;
	List<Transaction> getTransactionDetails(LocalDate date)
			throws OnlineException;
	public List<Customer> getCustomer(String name) throws OnlineException;

	public List<Transaction> getMiniStatement(long accId) throws OnlineException;
	public void updateCustomer( Customer customer ) throws OnlineException;
	public List<Transaction> getDetailedStatement(long accId, LocalDate fromDate,LocalDate toDate) throws OnlineException;
	public void updateUser( User user ) throws OnlineException;
public List<User> getUser(User user) throws OnlineException;
	public List<User> getUser(int id) throws OnlineException;
	int updateCustomerStatus(User use) throws OnlineException;
	public int addAccount(AccountMaster acc) throws OnlineException;
	public int operateServiceRequest(ServiceTracker service) throws OnlineException;
	public ServiceTracker getServiceTracker(int id) throws OnlineException;
	public List<ServiceTracker> getAllServiceTracker(int id,LocalDate rdate) throws OnlineException;	
	public List<Payee> getPayeeDetails(long accid) throws OnlineException;
	public AccountMaster getAccountDetails(long accId) throws OnlineException;
	public int addPayeeDetails(Payee payee) throws OnlineException;
	public int updateBalance(double bal,int accId) throws OnlineException;
	public int addTransaction(Transaction trans) throws OnlineException;
	


}
