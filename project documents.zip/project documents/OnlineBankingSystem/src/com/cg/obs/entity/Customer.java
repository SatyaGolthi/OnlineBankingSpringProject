package com.cg.obs.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;
@Entity
@Table(name="Customers")
public class Customer {
	@Id
	@Column(name="account_id")
	private int accountId;
	@Column(name="customer_name")
	private String customerName;
	
	@Column(name="Mobile_Number")
	private long mobile;
	@Column(name="email")
	private String email;
	@Column(name="address")
	private String address;
	@Column(name="pancard")
	private String pancard;
	
	
	public int getAccountId() {
		return accountId;
	}

	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public long getMobile() {
		return mobile;
	}

	public void setMobile(long mobile) {
		this.mobile = mobile;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPancard() {
		return pancard;
	}

	public void setPancard(String pancard) {
		this.pancard = pancard;
	}

	@Override
	public String toString() {
		return "Customer [accountId=" + accountId + ", customerName="
				+ customerName + ", mobile=" + mobile + ", email=" + email
				+ ", address=" + address + ", pancard=" + pancard + "]";
	}

	
	
}

