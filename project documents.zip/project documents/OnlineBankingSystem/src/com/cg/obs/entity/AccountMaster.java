package com.cg.obs.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="AccountMaster")
@SequenceGenerator(name = "account_id_seq",sequenceName="account_id_seq")
public class AccountMaster {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO,generator="account_id_seq")
	@Column(name="account_id")
	private int accountId;
	@Column(name="account_type")
	private String accountType;
	@Column(name="account_balance")
	private int accountBalance;
	@Column(name="open_date")
	private Date openDate;
	
	public Date getOpenDate() {
		return openDate;
	}
	public void setOpenDate(Date openDate) {
		this.openDate = openDate;
	}
	public int getAccountId() {
		return accountId;
	}
	public void setAccountId(int accoutId) {
		this.accountId = accoutId;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public int getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(int accountBalance) {
		this.accountBalance = accountBalance;
	}
	@Override
	public String toString() {
		return "Account_master [accountId=" + accountId + ", accountType="
				+ accountType + ", accountBlance=" + accountBalance
				+ ", openDate=" + openDate + "]";
	}
}
