package com.cg.obs.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="UserTable")
@SequenceGenerator(name="user_id_seq",sequenceName="user_id_seq")
public class User {
	@Id
	@Column(name="Account_ID")
	private int accId;
	
	@GeneratedValue(strategy=GenerationType.AUTO,generator="user_id_seq")
	@Column(name="user_id")
	private int userId;
	
	@Column(name="customer_name")
	private String name;
	
	@Column(name="login_password")
	private String loginPass;
	
	@Column(name="secret_question")
	private String ques;
	
	@Column(name="transaction_password")
	private String tranPass;
	
	@Column(name="lock_status")
	private char status;

	public int getAccId() {
		return accId;
	}

	public void setAccId(int accId) {
		this.accId = accId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLoginPass() {
		return loginPass;
	}

	public void setLoginPass(String loginPass) {
		this.loginPass = loginPass;
	}

	public String getQues() {
		return ques;
	}

	public void setQues(String ques) {
		this.ques = ques;
	}

	public String getTranPass() {
		return tranPass;
	}

	public void setTranPass(String tranPass) {
		this.tranPass = tranPass;
	}

	public char getStatus() {
		return status;
	}

	public void setStatus(char status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "User [accId=" + accId + ", userId=" + userId + ", name=" + name
				+ ", loginPass=" + loginPass + ", ques=" + ques + ", tranPass="
				+ tranPass + ", status=" + status + "]";
	}
	
	
}
