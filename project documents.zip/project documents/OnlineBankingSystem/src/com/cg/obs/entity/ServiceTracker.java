package com.cg.obs.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
@Entity
@Table(name="ServiceTracker")
@SequenceGenerator(name="service_id_seq",sequenceName="service_id_seq")
public class ServiceTracker {
	@Id
	@Column(name= "service_Id")
	@GeneratedValue(strategy=GenerationType.AUTO,generator="service_id_seq")
	private int serviceId;
	
	@Column(name= "service_Description")
	private String serviceDescription;
	@Column(name= "account_Id")
	private int accountId;
	@Column(name= "service_Raised_Date")
	private Date serviceRaisedDate;
	@Column(name= "service_Status")
	private String serviceStatus;
	public int getServiceId() {
		return serviceId;
	}
	public void setServiceId(int serviceId) {
		this.serviceId = serviceId;
	}
	public String getServiceDescription() {
		return serviceDescription;
	}
	public void setServiceDescription(String serviceDescription) {
		this.serviceDescription = serviceDescription;
	}
	public int getAccountId() {
		return accountId;
	}
	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}
	public Date getServiceRaisedDate() {
		return serviceRaisedDate;
	}
	public void setServiceRaisedDate(Date serviceRaisedDate) {
		this.serviceRaisedDate = serviceRaisedDate;
	}
	public String getServiceStatus() {
		return serviceStatus;
	}
	public void setServiceStatus(String serviceStatus) {
		this.serviceStatus = serviceStatus;
	}
	@Override
	public String toString() {
		return "ServiceTracker [serviceId=" + serviceId
				+ ", serviceDescription=" + serviceDescription + ", accountId="
				+ accountId + ", serviceRaisedDate=" + serviceRaisedDate
				+ ", serviceStatus=" + serviceStatus + "]";
	}
	
	
}