package com.cg.obs.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
@Entity
@Table(name="Transactions")
@SequenceGenerator(name="transaction_id_seq",sequenceName="transaction_id_seq")
public class Transaction {
	@Id 
	@GeneratedValue(strategy=GenerationType.AUTO,generator="transaction_id_seq")
	@Column(name="TRANSACTION_ID")
	private int transactionId;
	@Column(name="TRAN_DESCRIPTION")
	private String transactionDiscription;
	@Column(name="DATE_OF_TRANSACTION")
	private Date dateOfTransaction;
	@Column(name="TRANSACTION_TYPE")
	private String transactionType;
	@Column(name="TRAN_AMOUNT")
	private double	transactionAmount;
	@Column(name="ACCOUNT_ID")
	private int accountId;
	@Override
	public String toString() {
		return "Transactions [transactionId=" + transactionId + ", transactionDicription=" + transactionDiscription
				+ ", dateOfTransaction=" + dateOfTransaction + ", trnsactionType=" + transactionType
				+ ", transactionAmount=" + transactionAmount + ", accountId=" + accountId + "]";
	}
	
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public String getTransactionDiscription() {
		return transactionDiscription;
	}
	public void setTransactionDiscription(String transactionDiscription) {
		this.transactionDiscription = transactionDiscription;
	}
	public Date getDateOfTransaction() {
		return dateOfTransaction;
	}
	public void setDateOfTransaction(Date dateOfTransaction) {
		this.dateOfTransaction = dateOfTransaction;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public double getTransactionAmount() {
		return transactionAmount;
	}
	public void setTransactionAmount(double transactionAmount) {
		this.transactionAmount = transactionAmount;
	}
	public long getAccountId() {
		return accountId;
	}
	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}
	
	
}