package com.cg.obs.entity;

import java.util.Date;

public class FundTransferDetails {

	private Integer Fundtransferid;
	private Integer Accountid;
	private Integer Payeeaccountid;
	private Date Dateoftransfer;
	private Double Transferamount;
	public Integer getFundtransferid() {
		return Fundtransferid;
	}
	public void setFundtransferid(Integer fundtransferid) {
		Fundtransferid = fundtransferid;
	}
	public Integer getAccountid() {
		return Accountid;
	}
	public void setAccountid(Integer accountid) {
		Accountid = accountid;
	}
	public Integer getPayeeaccountid() {
		return Payeeaccountid;
	}
	public void setPayeeaccountid(Integer payeeaccountid) {
		Payeeaccountid = payeeaccountid;
	}
	public Date getDateoftransfer() {
		return Dateoftransfer;
	}
	public void setDateoftransfer(Date dateoftransfer) {
		Dateoftransfer = dateoftransfer;
	}
	public Double getTransferamount() {
		return Transferamount;
	}
	public void setTransferamount(Double transferamount) {
		Transferamount = transferamount;
	}
	
}
