package com.cg.obs.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="PayeeTable")
@SequenceGenerator(name = "payee_account_id_seq",sequenceName="payee_account_id_seq")
public class Payee {	
	
	@Column(name="account_id")
	private int accountId;
	
	@Id
	@Column(name="payee_account_id")
	@GeneratedValue(strategy=GenerationType.AUTO,generator="payee_account_id_seq")
	private int payeeId;
	
	@Column(name="nick_name")
	private String nickName;
	
	
	public long getAccountId() {
		return accountId;
	}
	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}
	public int getPayeeId() {
		return payeeId;
	}
	public void setPayeeId(int payeeId) {
		this.payeeId = payeeId;
	}
	public String getNickName() {
		return nickName;
	}
	public void setNickName(String nickName) {
		this.nickName = nickName;
	}
	@Override
	public String toString() {
		return "PayeeTable [accountId=" + accountId + ", payeeId=" + payeeId
				+ ", nickName=" + nickName + "]";
	}
	
}

